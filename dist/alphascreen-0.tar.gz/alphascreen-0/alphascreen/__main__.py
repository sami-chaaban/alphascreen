from alphascreen import decisiontree

def main():
    
    decisiontree.decide()

if __name__ == '__main__':

    main()