import os

__version__ = '0'
_ROOT = os.path.abspath(os.path.dirname(__file__))